import {createMachine, interpret} from 'xstate';
import {ChannelsContext} from '../channels';
import {default_t, JoinRoomPromise} from "../sockets";
import {RejectPromise} from "../base";

type ChannelJoinRoomEvent = {
    type: 'joinRoom';
    data: JoinRoomPromise;
}

type ChannelErrorEvent = {
    type: 'errorMessage';
    data: RejectPromise<{addresses: string[], clientId: string}>
}

type ChannelUpdatePresenceEvent = {
    type: 'updatePresence';
    presence: default_t;
}

type ChannelLeaveRoomEvent = {
    type: 'leaveRoom';
    clientId: string;
}

type ChannelSendMessageEvent = {
    type: 'sendMessage';
    message: string;
    clientId: string;
    assigns: default_t
    targets: string[] | 'all';
}

type ChannelSendMessageSuccessEvent = {
    message: string;
    clientId: string;
    targets: string[];
}

type ChannelService = {
    canPerformAction: {
        data: ChannelSendMessageSuccessEvent;
    }
}

type ChannelEvent = ChannelJoinRoomEvent | ChannelUpdatePresenceEvent | ChannelLeaveRoomEvent | ChannelSendMessageEvent | ChannelErrorEvent;

// @ts-ignore
const stateMachine =
    /** @xstate-layout N4IgpgJg5mDOIC5QGMAWBDAdpsAbWAdAJYS5gDEArgA4ToAuYACgE5xibJiKjUD2sIvSJ9MPEAA9EAZgIBGAAwAmABwAWDWoUBWORu0BOAOwAaEAE9EhpQW0KFRldoBs06cqXOAvl7NosOPjEpBRk6ABuYABKfHwAtuL8gsKi4lIISnKyRs4GKgbO+mpuas5mlgjOcnIEBgZauQrF+SoqPn4Y2HiEJGTkAFZ8RJgx8YkCQiJiSJKIALRK2gQK+QVGSkrrhdJq5Yi5Kstym9LOjipZbb4g-l1BvRSwHBAAsnCw6DDjyVNpiHIGGzKdZZaStIwrVR7BBuWQXHJVKradTabTtG6dQI9ELkMAsFh8FhvWAfL4zJKTVIzdJzC4ENR1C7FJRg5wKZxlCyIRwKAiqQpyVHKFxndG3LEEdCUeioQlEJ7E0kUCCiMDETDhPgAazV4u6kulspY8rAis+YAQw01yAYUwA2goALrfSnTUDpNnyZHOJQ6VxyXKLaHSYzyIx2FQswpGIxyMWY-VSmVyhXvc24-GEgjUXAMABmhLiBD1QSTRpNZpglo1fBtKUwDud5Im9b+lRqxQM9l97jkrTsuy5CDsBgISLUqgZp2kqh810wfAgcHEJexZBdrep-xZ9JDXZ0KmkfYcnIqRgM2XPqj0qI2aOuq4IsFQ0oAInwAO4jWIJZs-Knuv8SzOLoKjskoF7SNopQhtCKhGGo9JKFOh7KPBsbxgEiaGimpppmSvAtr8W4ZGBY4GFk7LaBB9gXto0JqGRR5nNobhOBsvreA+Cb4BuxGAQgcyKEsDJ5HoM6suyp6IJ4NSoWorGbBR4ZKHOXhAA */
    createMachine({
        tsTypes: {} as import("./channels.typegen").Typegen0,
        schema: {
            context: {} as ChannelsContext,
            events: {} as ChannelEvent,
            services: {} as ChannelService,
        },
        states: {
            idle: {
                on: {
                    updatePresence: {
                        actions: "modifyPresence",
                        target: "idle",
                        internal: false,
                    },
                    leaveRoom: [
                        {
                            actions: "modifyPresence",
                            cond: "atLeastOneUser",
                            target: "idle",
                            internal: false,
                        },
                        {
                            actions: "shutDownChannel",
                            target: "shutDownRoom",
                        },
                    ],
                    joinRoom: {
                        actions: "modifyPresence",
                        target: "idle",
                        internal: false,
                    },
                    sendMessage: {
                        target: "authoriseMessage",
                    },
                    errorMessage: {
                        actions: "sendErrorMessage",
                        target: "idle",
                        internal: false,
                    },
                },
            },
            shutDownRoom: {
                type: "final",
            },
            authoriseMessage: {
                invoke: {
                    src: "canPerformAction",
                    onDone: [
                        {
                            actions: "sendTheMessages",
                            target: "idle",
                        },
                    ],
                    onError: [
                        {
                            actions: "sendErrorMessage",
                            target: "idle",
                        },
                    ],
                },
            },
        },
        id: "channels",
        initial: "idle",
    }, {
        actions: {
            modifyPresence: (ctx, evt) => {
            },
            sendTheMessages: (ctx, evt) => {
            },
            sendErrorMessage: (ctx, evt) => {
            },
            shutDownChannel: (ctx, evt) => {
            },
        },
        guards: {
            atLeastOneUser: (ctx, evt) => true,
        },
        services: {
            canPerformAction: (ctx, evt) => {
                return Promise.resolve({
                    message: evt.message,
                    clientId: evt.clientId,
                    targets: [...evt.targets],
                });
            }
        }
    });

const interpreter = interpret(stateMachine);


