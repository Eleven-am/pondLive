import { createMachine } from 'xstate';

export interface SocketStateContext {
  socketId: string | null;
  rooms: string[];
  assigns: { [key: string]: string };
}

export type SocketStateEvent = { type: 'newConnection', socket: WebSocket}
    | {type: 'requestToJoinRoom', room: string, user: string}
    | {type: 'disconnect'}

const globalSocketsMachine =
/** @xstate-layout N4IgpgJg5mDOIC5RQDYHsBGBDFBlNAxgNZgAusAdAJYQpgDEAdmAO4DCajzBpVnioAA5pYVXvyQgAHogC0AVgCMAZgryAHPOUAWAAzLd2gEy6A7PIA0IAJ5zt6gGwV1e5Q6UrFR9coC+vq1RMHHxiMkosAFdSAAswRl4CLFJIUJJSegAnMABHSLhSABU0ACk0KkYAJTQ0AFsBEGFRcUYGmQQFUwoATm6HdW6fU3dTU0VFK1sO+ycXfVNleVNu03VFbX9A9Gw8QnSI6LiEqiSUiDSyeggqWAJOblIGprE+Vsl22SNlilMTbTddP1tL9lJM5MojKpjEZFA4VDo1opTP4AiBGGgIHAGkEdhdyNRaGAniIXhJQB9tCsfsMjO5dENlD4wR0NE57Fp5PJAUYjJz1JsQDiQntwhQorF4olkqkRY9JM8Wm05LSuiZ5HD1KZ7JDdOrmbJjIoKG5xit9BzvAKhbswviCOhYGAOFwwDxXsTmu73nJ1UaIYCljyjMDuqCbMqzBRdF8lg4tbz1RtUda8fB5STFd6WZpjSYRkGQ2GprJ3OoKMDeW4DOqqyjfEA */
createMachine({
  tsTypes: {} as import("./userSockets.typegen").Typegen0,
  schema: { context: {} as SocketStateContext, events: {} as SocketStateEvent },
  id: "globalSockets",
  initial: "idle",
  states: {
    idle: {
      on: {
        newConnection: [
          {
            actions: "addSocketToDB",
            cond: "accessAuthorised",
            target: "authenticatedSocket",
          },
          {
            actions: "rejectUser",
            target: "closeConnection",
          },
        ],
      },
    },
    authenticatedSocket: {
      on: {
        requestToJoinRoom: {
          actions: "addUserToRoom",
          target: "authenticatedSocket",
          internal: false,
        },
        disconnect: {
          actions: ["informOtherUsers", "clearUser"],
          target: "closeConnection",
        },
      },
    },
    closeConnection: {
      type: "final",
    },
  },
}, {
  actions: {
    addSocketToDB: (ctx: SocketStateContext, e: {type: 'newConnection', socket: WebSocket}) => {},
    rejectUser: (ctx: SocketStateContext, e: {type: 'newConnection', socket: WebSocket}) => {},

    addUserToRoom: (ctx: SocketStateContext, e: {type: 'requestToJoinRoom', room: string, user: string}) => {},

    informOtherUsers: (ctx: SocketStateContext) => {},
    clearUser: (ctx: SocketStateContext) => {},
  },
  guards: {
    accessAuthorised: (ctx: SocketStateContext, e: {type: 'newConnection', socket: WebSocket}) => (true),
  }
});
