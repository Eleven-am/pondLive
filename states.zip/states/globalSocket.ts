import {createMachine, interpret} from 'xstate';
import {
    AddSocketPromise,
    AddSocketToDB,
    AuthenticateRoom,
    GlobalSocketContext,
    GlobalSocketEvent, GlobalSocketService, IncomingRequest, JoinRoomPromise,
    RejectSocketConnection, SendErrorMessage, SocketJoinRoom, TerminateServer
} from "../sockets";

export const machine =
    /** @xstate-layout N4IgpgJg5mDOIC5RQDYHsBGBDFBlNAxgNZgAusAdAJYQpgDEEaAdmNcwG5okWqY75iZSjToIqnQllJUWAbQAMAXUSgADmlhUZLVSAAeiALQBGBQooAmACwmT1hQFYAnCYDsJy5ZMAaEAE9ELwAOCkdg92DnR2sAZgA2eOC3SwBfVL8+bDxCEnJqWgYwACditGKKNRRpADNygFtedGzBPJFC8UkCaVlmRRUkEA0tHWY9QwRTcytbeydXDy9fAKC3eLCkzzW3azjLJ3TM5oFc4QpisCwIf3pYAAsAV1ImAHcxweHtXvGg4PXg7yONxuRyxWLOSwAvyBSYmGIUdyxYLWRz7EzOXY7Q4gLInIT5C5XG4lMrFPSfUY-BCQ-6A4Gg8GQyzQ4z7SwI+IKEzBMGxSxuBTBBRubG4nL4yiE670C4ARwecFIABU0AApNASABKaDQ9XJmi+ukGEyMqIoSOibiFC083hZCG5FhcMUc9k8zicKNFx3FbXOl2lrBeAFU1FBilcwJqwPLFfqRt9jcYXBQBZZovNrPyEij7UZAVYAY4FFmokCId7+L6zs0MDcmKx2FweGLWjXMHXOlxuqN+vHDe9QCa4k6y1nnJyuZZHPb1vFUdZOXzXM5YsXnJWWqd8rXiaVypVqqQ6sVGq3t5Rd12pL3lP3KUnYdMbHYHC53LbljDVxR4l4YgK6LOCCnibnifpYE8dzlFQsAlIwLBsBIzZsOeEoUJBpDQcUsElNePa9H2HwGg+Q7GM4zjmsi8QmGC07Chi8R5rRlHWMEQImEkPJuBi1hgdW+SYdhuHFPQJIHlUtQNE0VZtoJUEwXBxT4T08h3sRCZGmRsKcRQFFLG4sQKDRKI8Xmi4UKZC6OPEKJxFm6QZCAzBoBAcB6GhfqiGA96JtpRhghYhmcQoRnOBEcLOPa3jWBQgqopxrprE4wL8XJkoBjC6gkX5BiIOisRhKili2Q40RJKizEUb+f4pMC4V8go05pReFCkCU9QSNIYC4CUHAlL5Wl5QgWYmFYRlePErguCkzIrJM3ihIkYLBQKnqxHxTmee2GB1oNg7DUYhluJZ3hNVmwqREx82mqEKI2U1lpTVaG5bT66UYQpOFKftVIBTyCIYik3Iuui10wqYERWBifIChRSUpC1Eq-Y+R00adZg2PsHhWuDrIer+xbhFywGrkKm3pEAA */
    createMachine({
  tsTypes: {} as import("./globalSocket.typegen").Typegen0,
  schema: {
    context: {} as GlobalSocketContext,
    events: {} as GlobalSocketEvent,
    services: {} as GlobalSocketService,
  },
  states: {
    idle: {
      invoke: {
        src: "setupServer",
        onDone: [
          {
            target: "ready",
          },
        ],
        onError: [
          {
            target: "terminateServer",
          },
        ],
      },
    },
    ready: {
      on: {
        shutdown: {
          target: "terminateServer",
        },
        error: {
          target: "terminateServer",
        },
        requestToJoinRoom: {
          target: "lobby",
        },
        newUpgradeRequest: {
          target: "authoriser",
        },
      },
    },
    terminateServer: {
      entry: "shutDownServer",
      type: "final",
    },
    lobby: {
      invoke: {
        src: "authenticateRoom",
        onDone: [
          {
            actions: "joinRoom",
            target: "ready",
          },
        ],
        onError: [
          {
            actions: "sendErrorMessage",
            target: "ready",
          },
        ],
      },
    },
    authoriser: {
      invoke: {
        src: "authenticateSocket",
        onDone: [
          {
            actions: "addSocketToDB",
            target: "ready",
          },
        ],
        onError: [
          {
            actions: "rejectSocketConnection",
            target: "ready",
          },
        ],
      },
    },
  },
  id: "globalSockets",
  initial: "idle",
}, {
        actions: {
            sendErrorMessage: (context, event) => sendErrorMessage(context, event),
            joinRoom: (context, event) => joinRoom(context, event),
            addSocketToDB: (context, event) => addSocketToDB(context, event),
            rejectSocketConnection: (context, event) => rejectSocketConnection(context, event),
            shutDownServer: (context, event) => shutDownServer(context, event),
        },
        services: {
            authenticateRoom: (context, event) => authenticateRoom(context, event),
            authenticateSocket: (context, event) => authenticateSocket(context, event),
            setupServer: (context) => setupServer(context),
        },
    });

const interpreter = interpret(machine);

const sendErrorMessage = (context: GlobalSocketContext, event: SendErrorMessage) => {
}

const joinRoom = (context: GlobalSocketContext, event: SocketJoinRoom) => {
}

const addSocketToDB = (context: GlobalSocketContext, event: AddSocketToDB) => {
}

const rejectSocketConnection = (context: GlobalSocketContext, event: RejectSocketConnection) => {
}

const shutDownServer = (context: GlobalSocketContext, event: TerminateServer) => {
}

const authenticateRoom = async (context: GlobalSocketContext, event: AuthenticateRoom): Promise<JoinRoomPromise> => {
    return new Promise<JoinRoomPromise>((resolve, reject) => {
    })
}

const authenticateSocket = async (context: GlobalSocketContext, event: IncomingRequest): Promise<AddSocketPromise> => {
    return new Promise<AddSocketPromise>((resolve, reject) => {
    })
}

const setupServer = async (context: GlobalSocketContext): Promise<void> => {}
