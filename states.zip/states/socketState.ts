export interface SocketStateContext {
  socketId: string | null;
  rooms: string[];
  assigns: { [key: string]: string };
}

export type SocketStateEventType = 'newConnection' | 'disconnect' | 'requestToJoinRoom';


interface Actions {
  generateUUID: (context: SocketStateContext) => void;
  addSocketToDB: (context: SocketStateContext, event: {socket: WebSocket}) => void;
  addUserToRoom: (context: SocketStateContext, event: { room: string, user: string }) => void;
  sendUserErrorMessage: (context: SocketStateContext, event: { message: any }) => void;
  informOtherUsers: (context: SocketStateContext, event: { message: any }) => void;
  clearUser: (context: SocketStateContext, event: { user: string }) => void;
  rejectUser: (context: SocketStateContext, event: { message: any }) => void;
}

export interface SocketStateActions extends Partial<Actions> {
  type: SocketStateEventType;
}

interface Guards {
  accessAuthorised: (context: SocketStateContext, event: (queries: URLSearchParams) => boolean) => boolean;
  canAccessRoom: (context: SocketStateContext, event: (queries: {[p: string]: string}) => boolean) => boolean;
}

export interface SocketStateGuards extends Partial<Guards> {
    type: SocketStateEventType;
}

export type SocketStateEvent = { type: 'newConnection', socket: WebSocket}
    | {type: 'requestToJoinRoom', room: string, user: string}
    | {type: 'disconnect'}

export const socketState = {
  id: "globalSockets",
  initial: "idle",
  states: {
    idle: {
      on: {
        newConnection: [
          {
            actions: ["generateUUID", "addSocketToDB"],
            cond: "accessAuthorised",
            target: "authenticatedSocket",
          },
          {
            actions: "rejectUser",
            target: "closeConnection",
          },
        ],
      },
    },
    authenticatedSocket: {
      on: {
        requestToJoinRoom: [
          {
            actions: "addUserToRoom",
            cond: "canAccessRoom",
            target: "authenticatedSocket",
            internal: false,
          },
          {
            actions: "sendUserErrorMessage",
            target: "authenticatedSocket",
            internal: false,
          },
        ],
        disconnect: {
          actions: ["informOtherUsers", "clearUser"],
          target: "closeConnection",
        },
      },
    },
    closeConnection: {},
  },
  schema: {
    context: {} as SocketStateContext,
    actions: {} as SocketStateActions,
    guards: {} as SocketStateGuards,
    events: {} as SocketStateEvent,
  }
}
