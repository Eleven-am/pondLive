import { assert } from 'chai';
import { socketState } from './socketState';
import { createMachine, interpret } from 'xstate';

const globalSocketsMachine = createMachine({
    ...socketState,
    id: "globalTestSockets",
    context: {
        socketId: null,
        rooms: [],
        assigns: {},
    }
});

describe('globalSocketsMachine', () => {
    it('should have the correct initial state', () => {
        const service = interpret(globalSocketsMachine);
        service.start();
        assert.equal(service.state.value, 'idle');
    })
    it('should transition to authenticatedSocket when a new connection is made and user is authorised', () => {
        const service = interpret(globalSocketsMachine);
        service.start();
        service.send('newConnection', {authorised: true});
        assert.equal(service.state.value, 'authenticatedSocket');
    })
    it('should transition to closeConnection when a new connection is made and user is not authorised', () => {
        const service = interpret(globalSocketsMachine);
        service.start();
        service.send('newConnection', {authorised: false});
        assert.equal(service.state.value, 'closeConnection');
    })

    it('should transition to closeConnection when a disconnect event is sent', () => {
        const service = interpret(globalSocketsMachine);
        service.start();
        service.send('newConnection', {authorised: true});
        service.send('disconnect');
        assert.equal(service.state.value, 'closeConnection');
    })
});
